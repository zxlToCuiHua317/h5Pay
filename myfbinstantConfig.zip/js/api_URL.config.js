const api_URL = {
    payUrl: "yh-ntt-fxjl.kylgame.com/yh-pay-fxjl",
    appsmobileUrl: "yh-ntt-fxjl.kylgame.com/yh-appsmobile-fxjl",
    loginUrl: "yh-ntt-fxjl.kylgame.com/yh-login-fxjl"
}