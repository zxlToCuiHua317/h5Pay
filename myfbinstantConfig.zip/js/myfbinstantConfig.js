 var myFbinstantConfig = {
 	appid: "540954993254752",
 	gameCode: "NAJB",
 	siteCode: "NAJBFBINSTANT",
 	language: "TW",
 	os: "fbins",
 	myfbPortUrl: "//xjsfnajbrql.95vy.com/lanjzk/port/fbinstantUserLoginForH5Game.do",
 	myfbLogintUrl: "//xjsfnajbrql.95vy.com/wuniah/login/userMobileAuth.do",
 	myfbPayInitUrl: "//xjsfnajbrql.95vy.com/ybqwls/iapFb/initFbinstantPay.do",
 	myfbPayCallBackUrl: "//xjsfnajbrql.95vy.com/ybqwls/iapFb/FbinstantPayFeedBack.do",
 	myfbuserUpgradeAccountUrl: "//xjsfnajbrql.95vy.com/wuniah/login/userUpgradeAccountFromGame.do",
 	INTERSTITIAL_PLACEMENT_ID: "", //插屏广告
 	REWARDED_PLACEMENT_ID: "", //奖励式视频广告
 	packageVersion: "1.0"
 }