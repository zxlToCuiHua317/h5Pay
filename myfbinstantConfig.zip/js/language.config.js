const AllLanguage = {
    //台湾
    TW_Language: {
        officialPay: "官方平台支付",
        otherPay: "第三方支付",
        account: "账号",
        point: "點數",
        insufficientTip: "(你的L点不足，请先充值L点)",
        exchange: "兑换",
        buyPoint: "購買點數",
        username: "用戶名",
        codeNum: "卡號",
        codePass: "卡密",
        codeDes: "請輸入點數卡號",
        codePassDes: "請輸入密碼",
        point_pt:"平台點",
        L_Point:"L點"
    }
}